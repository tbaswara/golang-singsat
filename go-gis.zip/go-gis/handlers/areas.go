package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"

	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
)

type AreaFeature struct {
	Type       string                 `json:"type"`
	Geometry   json.RawMessage        `json:"geometry"`
	Properties map[string]interface{} `json:"properties"`
}

type AreaCollection struct {
	Type     string        `json:"type"`
	Features []AreaFeature `json:"features"`
}

func GetAreas(c *gin.Context) {
	db, err := sql.Open("postgres", "user=postgres password=root dbname=gisdb sslmode=disable")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	defer db.Close()

	rows, err := db.Query(`SELECT id, name, population, ST_AsGeoJSON(geom) FROM areas`)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	defer rows.Close()

	features := []AreaFeature{}
	for rows.Next() {
		var id int
		var name string
		var population int
		var geom string

		if err := rows.Scan(&id, &name, &population, &geom); err != nil {
			continue
		}

		features = append(features, AreaFeature{
			Type:     "Feature",
			Geometry: json.RawMessage(geom),
			Properties: map[string]interface{}{
				"id":         id,
				"name":       name,
				"population": population,
			},
		})
	}

	fc := AreaCollection{
		Type:     "FeatureCollection",
		Features: features,
	}

	c.JSON(http.StatusOK, fc)
}
