package handlers

import (
	"database/sql"
	"encoding/json"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
)

type Feature struct {
	Type       string                 `json:"type"`
	Geometry   json.RawMessage        `json:"geometry"`
	Properties map[string]interface{} `json:"properties"`
}

type FeatureCollection struct {
	Type     string    `json:"type"`
	Features []Feature `json:"features"`
}

func GetPoints(c *gin.Context) {
	db, err := sql.Open("postgres", "user=postgres password=root dbname=gisdb sslmode=disable")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	defer db.Close()

	rows, err := db.Query(`SELECT id, name,population, ST_AsGeoJSON(geom) FROM points_of_interest`)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	defer rows.Close()

	features := []Feature{}

	for rows.Next() {
		var id int
		var name string
		var population string
		var geom string

		if err := rows.Scan(&id, &name, &population, &geom); err != nil {
			continue
		}

		features = append(features, Feature{
			Type:     "Feature",
			Geometry: json.RawMessage(geom),
			Properties: map[string]interface{}{
				"id":         id,
				"name":       name,
				"population": population,
			},
		})
	}

	fc := FeatureCollection{
		Type:     "FeatureCollection",
		Features: features,
	}

	log.Printf("Returning %d features", len(features))

	c.JSON(http.StatusOK, fc)
}
