package main

import (
	"go-gis/handlers"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

func handleRegions(c *gin.Context) {
	regions := []string{
		"Kabupaten Bandung",
		"Kabupaten Bandung Barat",
		"Kabupaten Bekasi",
		"Kabupaten Bogor",
		"Kabupaten Ciamis",
		"Kabupaten Cianjur",
		"Kabupaten Garut",
		"Kabupaten Indramayu",
		"Kabupaten Karawang",
		"Kabupaten Kuningan",
		"Kabupaten Majalengka",
		"Kabupaten Pangandaran",
		"Kabupaten Purwakarta",
		"Kabupaten Subang",
		"Kabupaten Sukabumi",
		"Kabupaten Sumedang",
		"Kabupaten Tasikmalaya",
		"Kota Bandung",
		"Kota Banjar",
		"Kota Bekasi",
		"Kota Bogor",
		"Kota Cimahi",
		"Kota Cirebon",
		"Kota Depok",
		"Kota Sukabumi",
		"Kota Tasikmalaya",
	}

	c.JSON(http.StatusOK, regions)
}

func main() {
	r := gin.Default()

	// Serve HTML template
	r.LoadHTMLGlob("templates/*.html")
	r.GET("/regions", handleRegions)

	// Serve index page
	r.GET("/", func(c *gin.Context) {
		c.HTML(http.StatusOK, "index.html", nil)

	})

	// Serve static GeoJSON API
	r.GET("/geojson", handlers.GetPoints)
	r.GET("/bandung", func(c *gin.Context) {
		data, err := os.ReadFile("data/bandung.geojson")
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "GeoJSON not found"})
			return
		}
		c.Data(http.StatusOK, "application/json", data)
	})

	r.GET("/areas", handlers.GetAreas)
	r.GET("/borders", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"type": "FeatureCollection",
			"features": []gin.H{
				{
					"type": "Feature",
					"geometry": gin.H{
						"type": "MultiLineString",
						"coordinates": [][][]float64{
							{
								{107.6, -6.9},
								{107.7, -6.91},
							},
							{
								{107.8, -6.92},
								{107.9, -6.93},
							},
						},
					},
					"properties": gin.H{
						"name": "West Java Border",
					},
				},
			},
		})
	})

	r.Run(":8080")
}
